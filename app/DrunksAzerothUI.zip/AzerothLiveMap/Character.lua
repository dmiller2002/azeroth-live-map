local _, ns = ...
local records, order, urgent, queued = {}, {}, {}, {}
local revision, cursor, active = 0, 1, nil
local schedule = ns.Schedule(1, 15)
function ns.InvalidateCharacter() schedule:Invalidate() end

local function Number(value, maximum)
    if not ns.IsReadable(value) or type(value) ~= "number" or value ~= value or value == math.huge or value == -math.huge then return 0 end
    return math.floor(math.max(0, math.min(maximum or 65535, value)))
end
local function Put(bytes, value, size)
    value = Number(value, 256 ^ size - 1)
    for i = size - 1, 0, -1 do bytes[#bytes + 1] = math.floor(value / 256 ^ i) % 256 end
end
local function Text(value, limit)
    value = ns.IsReadable(value) and type(value) == "string" and value or ""
    value = value:gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""):gsub("[%c]", " ")
    if #value > limit then
        local cut = limit + 1
        while cut > 1 and value:byte(cut) >= 128 and value:byte(cut) < 192 do cut = cut - 1 end
        value = value:sub(1, cut - 1)
    end
    return value
end

-- Restricted values are never compared or encoded. Max wire values mean
-- unavailable; the desktop shows a dash while equipment continues syncing.
local function Stat(fn, effective, ...)
    if type(fn) ~= "function" then return nil end
    local ok, base, value = pcall(fn, ...)
    if not ok then return nil end
    if effective then
        if not ns.IsReadable(value) then return nil end
        if value == nil then value = base end
    else value = base end
    if ok and ns.IsReadable(value) and type(value) == "number" then return value end
end
local function PutStat(bytes, value, size)
    Put(bytes, value == nil and (256 ^ size - 1) or value, size)
end
local function Record(key, kind, index, payload, text)
    local signature = table.concat(payload, ",") .. "|" .. (text or "")
    local old = records[key]
    if old and old.signature == signature then return end
    revision = (revision + 1) % 65536
    local packets = {{kind = kind, index = index, payload = payload}}
    if text and text ~= "" then
        for offset = 0, math.ceil(#text / 10) - 1 do
            local fragment = {offset + ((offset + 1) * 10 >= #text and 128 or 0)}
            for i = 1, 10 do fragment[#fragment + 1] = text:byte(offset * 10 + i) or 0 end
            packets[#packets + 1] = {kind = 2, index = index, payload = fragment}
        end
    end
    records[key] = {signature = signature, generation = revision, packets = packets, cursor = 1}
    if not old then order[#order + 1] = key end
    if not queued[key] then urgent[#urgent + 1] = key; queued[key] = true end
end

local function Refresh()
    if not UnitName or not UnitClass or not GetInventoryItemID then return false end
    local name, realm = UnitName("player")
    if not name then return false end
    local _, _, classID = UnitClass("player")
    local raceName, _, raceID = UnitRace("player")
    local className = UnitClass("player")
    local gameVersion, gameBuild
    if GetBuildInfo then gameVersion, gameBuild = GetBuildInfo() end
    local payload = {}
    Put(payload, UnitLevel("player"), 2)
    payload[3], payload[4], payload[5] = Number(classID, 255), Number(raceID, 255), Number(UnitSex("player"), 3)
    payload[6] = Number(UnitPowerType("player"), 255)
    Record("identity", 0, 0, payload, table.concat({Text(name,48),Text(realm or (GetRealmName and GetRealmName()),96),Text(raceName,64),Text(className,64),Text(gameVersion,24),Text(gameBuild,16)},"\n"))
    payload = {}
    for stat = 1, 5 do PutStat(payload, Stat(UnitStat, true, "player", stat), 2) end
    Record("primary", 3, 1, payload)
    payload = {}
    PutStat(payload, Stat(UnitArmor, true, "player"), 3)
    PutStat(payload, Stat(UnitHealthMax, false, "player"), 3)
    PutStat(payload, Stat(UnitPowerMax, false, "player"), 3)
    Record("defense", 3, 2, payload)
    local itemInfo = C_Item and C_Item.GetItemInfo or GetItemInfo
    for slot = 1, 19 do
        local itemID = Number(GetInventoryItemID("player", slot), 16777215)
        local itemName, quality, itemLevel
        if itemID > 0 and itemInfo then
            local link = GetInventoryItemLink and GetInventoryItemLink("player", slot)
            local info = {itemInfo(link or itemID)}
            itemName, quality, itemLevel = info[1], info[3], info[4]
        end
        local durability, maximum
        if GetInventoryItemDurability then durability, maximum = GetInventoryItemDurability(slot) end
        payload = {}; Put(payload, itemID, 3)
        payload[4] = quality and Number(quality, 7) or 255
        Put(payload, itemLevel, 2); Put(payload, durability, 2); Put(payload, maximum, 2)
        Record("slot" .. slot, 1, slot, payload, itemID > 0 and Text(itemName, 100) or nil)
    end
    return true
end

-- v4 shares the existing auxiliary lanes. Each equipment slot has its own
-- revision, so a stat change cannot restart or mix another item's name.
function ns.CharacterPacket(sequence, now)
    if schedule:Due(now) and not pcall(Refresh) then schedule:Invalidate() end
    if #order == 0 then return nil end
    if not active then
        active = table.remove(urgent, 1)
        if active then queued[active] = nil
        else active = order[cursor]; cursor = cursor % #order + 1 end
    end
    local record = records[active]
    local packet = record.packets[record.cursor]
    record.cursor = record.cursor + 1
    if record.cursor > #record.packets then record.cursor = 1; active = nil end
    return ns.EncodeQuest(packet.kind, sequence, ns.QuestSession or 0, record.generation, packet.index, packet.payload, 4)
end

ns.pending[#ns.pending + 1] = function() return #urgent > 0 end
